package com.example.final_project;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;

public record Loan(double annualInterestRate, int numberOfYears, double loanAmount) implements Serializable {
    @Serial
    private static final long serialVersionUID = 0L;

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public int getNumberOfYears() {
        return numberOfYears;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (obj == null || obj.getClass() != this.getClass()) return false;
        var that = (Loan) obj;
        return Double.doubleToLongBits(this.annualInterestRate) == Double.doubleToLongBits(that.annualInterestRate) &&
                this.numberOfYears == that.numberOfYears &&
                Double.doubleToLongBits(this.loanAmount) == Double.doubleToLongBits(that.loanAmount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(annualInterestRate, numberOfYears, loanAmount);
    }

    @Override
    public String toString() {
        return "Loan[" +
                "annualInterestRate=" + annualInterestRate + ", " +
                "numberOfYears=" + numberOfYears + ", " +
                "loanAmount=" + loanAmount + ']';
    }


}

